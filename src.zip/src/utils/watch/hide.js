"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var common_1 = require("../common");
function default_1(e) {
    if ((0, common_1.setDoTime)('hide')) {
        (0, common_1.request)(e, 'hide');
    }
}
exports.default = default_1;
